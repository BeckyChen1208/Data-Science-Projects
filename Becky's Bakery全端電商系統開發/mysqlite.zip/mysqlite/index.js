const express = require('express');
const path = require('path');
const sqlite3 = require('sqlite3').verbose();

const app = express();
const port = 3000;

// 解析 JSON 格式的請求主體
app.use(express.json());

// 建立 SQLite 連線
const db = new sqlite3.Database('test_user.db', (err) => {
  if (err) {
    console.error('Error connecting to SQLite:', err);
  } else {
    console.log('Connected to SQLite');
    // 如果表格不存在，創建 users 表格
    db.run(`CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT,
      sex TEXT,
      tel TEXT,
      email TEXT,
      address TEXT,
      password TEXT
    )`);
  }
});

app.get('/user', (req, res) => {
  res.sendFile(path.join(__dirname, 'vip.html'));
});

app.get('/vip1', (req, res) => {
  res.sendFile(path.join(__dirname, 'vip1.html'));
});

app.get('/users', (req, res) => {
  db.all('SELECT * FROM users', (err, rows) => {
    if (err) {
      console.error('Error querying SQLite:', err);
      res.status(500).json({ error: 'Internal Server Error' });
    } else {
      res.json({ users: rows });
    }
  });
});

app.post('/addUser', (req, res) => {
  const newUser = req.body;
  const query = 'INSERT INTO users (name, sex, tel, email, address, password) VALUES (?, ?, ?, ?, ?, ?)';
  const params = [newUser.name, newUser.sex, newUser.tel, newUser.email, newUser.address, newUser.password];

  db.run(query, params, function(err) {
    if (err) {
      console.error('Error adding user to SQLite:', err);
      res.status(500).json({ success: false, message: 'Internal server error.' });
    } else {
      res.json({ success: true, message: 'User added successfully.', userId: this.lastID });
    }
  });
});

// 關閉 SQLite 連線，當應用程式結束時
process.on('exit', () => {
  db.close();
  console.log('SQLite connection closed');
});

app.listen(port, () => {
  console.log(`Express app listening at http://localhost:${port}`);
});
